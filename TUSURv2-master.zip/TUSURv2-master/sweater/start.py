from sweater import app

if __name__ == "__main__":
    app.run(debug=False, port=2024)

